﻿JMO Assets
© 2014, Jean Moreno
===================

Thanks for your download(s)! :)

You will find in addition to your package(s) a new menu option: "Window/JMO Assets/"
This will help you determine if you need to update any package, or send an email
if you need support.


"Window > JMO Assets > Check for updates"
------------------------------------------
Open a window that checks for updates by comparing your local version with the current
Asset Store version, and brings you to the product Asset Store page in one click!
The Readme files are used to check the local version, so the plugin will not see the
local version if these are deleted.


"Window > JMO Assets > View FAQ"
------------------------------------------
Opens your default web browser to the JMO Assets FAQ page. Please look here for any question before sending me an email!


"Window > JMO Assets > Email support"
------------------------------------------
Opens your default mail client to send an email to jean.moreno.public+unity@gmail.com
if you need support, or anything else.
