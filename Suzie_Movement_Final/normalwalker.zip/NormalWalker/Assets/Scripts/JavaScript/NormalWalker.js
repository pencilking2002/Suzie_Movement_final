///////////////////////////////////////////////////////////////////////
//                                                   41 Post                                       //
// Created by DimasTheDriver on June/22/2011                                    //
// Part of 'Unity: Normal Walker' post.                          		 		 //
// Available at:     http://www.41post.com/?p=4123                              //
/////////////////////////////////////////////////////////////////////


//this game object's Transform
private var goTransform:Transform;
	
//the speed to move the game object
private var speed:float = 6.0f;
//the gravity
private var gravity:float = 50.0f;
	
//the direction to move the character
private var moveDirection:Vector3 = Vector3.zero;
//the attached character controller
private var cController:CharacterController;
	
//a ray to be cast 
private var ray:Ray;
//A class that stores ray collision info
private var hit:RaycastHit;
	
//a class to store the previous normal value
private var oldNormal:Vector3;
//the threshold, to discard some of the normal value variations
public var threshold:float = 0.009f;

// Use this for initialization
function Start () 
{
	//get this game object's Transform
	goTransform = this.GetComponent(Transform);
	//get the attached CharacterController component
	cController = GetComponent(CharacterController);
}
	
// Update is called once per frame
function Update () 
{
	//cast a ray from the current game object position downward, relative to the current game object orientation
	ray = new Ray(goTransform.position, -goTransform.up);  
	
	//if the ray has hit something
	if(Physics.Raycast(ray.origin,ray.direction, hit, 5))//cast the ray 5 units at the specified direction  
	{  
		//if the current goTransform.up.y value has passed the threshold test
		if(oldNormal.y >= goTransform.up.y + threshold || oldNormal.y <= goTransform.up.y - threshold)
		{
			//set the up vector to match the normal of the ray's collision
			goTransform.up = hit.normal;
		}
		//store the current hit.normal inside the oldNormal
		oldNormal =  hit.normal;
	}  
	
	//move the game object based on keyboard input
	moveDirection = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
	//apply the movement relative to the attached game object orientation
	moveDirection = goTransform.TransformDirection(moveDirection);
	//apply the speed to move the game object
	moveDirection *= speed;
	
	// Apply gravity downward, relative to the containing game object orientation
	moveDirection.y -= gravity * Time.deltaTime * goTransform.up.y;
	
	// Move the game object
	cController.Move(moveDirection * Time.deltaTime);
}