///////////////////////////////////////////////////////////////////////
//                                                   41 Post                                       //
// Created by DimasTheDriver on June/22/2011                                    //
// Part of 'Unity: Normal Walker' post.                          		 		 //
// Available at:     http://www.41post.com/?p=4123                              //
/////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;

public class BackToPost : MonoBehaviour 
{
	void OnGUI()
	{
		if(GUI.Button(new Rect(Screen.width-110,Screen.height-40,100,30),"Back to post..."))
		{
			Application.OpenURL("http://www.41post.com/?p=4123");
			
		}
	}
}
