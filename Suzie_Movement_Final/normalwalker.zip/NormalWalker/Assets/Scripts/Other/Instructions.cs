using UnityEngine;
using System.Collections;

public class Instructions : MonoBehaviour 
{
	void OnGUI () 
	{
		GUI.Label(new Rect(20,20,400,200),"Use the WASD or the arrow keys to move the blue cubes. Only the C# version of the script is being used.");
	}
}
